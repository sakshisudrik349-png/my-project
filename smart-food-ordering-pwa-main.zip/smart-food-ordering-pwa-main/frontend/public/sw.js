const CACHE = 'campus-smart-eats-v1';
const toCache = [ '/', '/index.html', '/manifest.json' ];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(toCache))); });
self.addEventListener('activate', (e) => { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', (e) => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});

// simple push notification handler
self.addEventListener('push', event => {
  const data = event.data?.json() || { title: 'Campus Smart Eats', body: 'You have a notification' };
  event.waitUntil(self.registration.showNotification(data.title, { body: data.body }));
});
