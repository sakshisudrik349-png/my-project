const mongoose = require('mongoose');
const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  items: [{ meal: { type: mongoose.Schema.Types.ObjectId, ref: 'Meal' }, qty: Number, price: Number }],
  total: Number,
  status: { type: String, enum: ['Preparing','Ready','Completed','Cancelled'], default: 'Preparing' },
  payment: { provider: String, paid: { type: Boolean, default: false }, paymentId: String },
  pickupAt: Date
}, { timestamps: true });
module.exports = mongoose.model('Order', orderSchema);
