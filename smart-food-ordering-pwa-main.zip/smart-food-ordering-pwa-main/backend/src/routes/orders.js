const express = require('express');
const Order = require('../models/Order');
const router = express.Router();
const Razorpay = require('razorpay');

// create order
router.post('/', async (req, res) => {
  try {
    const { user, items, total, payment } = req.body; // payment: { provider }
    const order = new Order({ user, items, total, payment });
    await order.save();

    // notify admin channel via socket
    req.io.to('admins').emit('new-order', order);

    res.json(order);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// admin updates order status
router.put('/:id/status', async (req, res) => {
  const { status } = req.body;
  const o = await Order.findByIdAndUpdate(req.params.id, { status }, { new: true });
  // emit to clients
  req.io.emit('order-updated', o);
  res.json(o);
});

// list orders
router.get('/', async (req, res) => {
  const { userId } = req.query;
  const q = userId ? { user: userId } : {};
  const orders = await Order.find(q).populate('items.meal').sort({ createdAt: -1 });
  res.json(orders);
});

// Razorpay order creation (server-side) - minimal example
router.post('/razorpay/create', async (req, res) => {
  const Razorpay = require('razorpay');
  const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
  const { amount, currency, receipt } = req.body; // amount in paise
  try {
    const resp = await rzp.orders.create({ amount, currency: currency || 'INR', receipt });
    res.json(resp);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
