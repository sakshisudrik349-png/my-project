const express = require('express');
const Meal = require('../models/Meal');
const router = express.Router();

router.get('/', async (req, res) => {
  const meals = await Meal.find().sort({ createdAt: -1 });
  res.json(meals);
});

router.post('/', async (req, res) => {
  // admin only — minimal check, extend in production
  const { name, description, price, image, tags } = req.body;
  const m = new Meal({ name, description, price, image, tags });
  await m.save();
  res.json(m);
});

router.put('/:id', async (req, res) => {
  const m = await Meal.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(m);
});

router.delete('/:id', async (req, res) => {
  await Meal.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
