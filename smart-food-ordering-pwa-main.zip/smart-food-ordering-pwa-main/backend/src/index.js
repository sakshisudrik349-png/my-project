require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth');
const mealsRoutes = require('./routes/meals');
const ordersRoutes = require('./routes/orders');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL || '*' }
});

app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/meals', mealsRoutes);
app.use('/api/orders', ordersRoutes);

// make io available in req
app.use((req, res, next) => { req.io = io; next(); });

const PORT = process.env.PORT || 5000;

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('MongoDB connected');
    server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch(err => console.error(err));

// basic Socket.IO connection
io.on('connection', (socket) => {
  console.log('socket connected:', socket.id);
  socket.on('join-admin', () => socket.join('admins'));
  socket.on('disconnect', () => console.log('socket disconnected', socket.id));
});
