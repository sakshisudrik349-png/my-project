const mongoose = require('mongoose');
const mealSchema = new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  image: String,
  available: { type: Boolean, default: true },
  tags: [String]
}, { timestamps: true });
module.exports = mongoose.model('Meal', mealSchema);
