# smart-food-ordering-pwa
Smart Food Ordering &amp; Mess Management System (PWA) for MIT-ADT University.  A Progressive Web App for students, teachers, and visitors to order meals,  track orders, and for mess/café admins to manage menus, orders, and revenue efficiently.
